﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

/* This script adds functionality to the Virus in GrabEmAll, which makes
 * the player lose points when they pick it up.
 * The script also contains functionality for swapping gravityScale, and disabling rigidbody2D or collision, which can be called
 * from outside of the prefab when it is being created.
 */
public class VirusScript : MonoBehaviour
{

    // Start is called before the first frame update. During the course of the game, this is called whenever a virus object is generated.
    void Start()
    {
        float range = Random.Range(-10f, -5f); //Generates the reverse gravityScale so the prefab ascends rather than descends.
        FindObjectOfType<AudioManager>().Play("Bird3"); //Plays the sound in the AudioManager array titled "Bird3"
        Rigidbody2D gravity = gameObject.GetComponent<Rigidbody2D>(); //Acquires access to the rigidbody so that gravityScale can be changed.
        gravity.gravityScale = range;
        StartCoroutine(ExecuteAfterTime(5)); //Starts the function (ExecuteAfterTime) after 5 seconds.

    }
    //The IEnumerator is called during the start function to put a delay on when the gravity flips. It contains
    //code for randomising the value applied to the gravityScale, and also plays a sound to signify the swap (for testing).
    IEnumerator ExecuteAfterTime(float time)
    {
        yield return new WaitForSeconds(time);
        float range = Random.Range(3f, 12f); //Random.range generates a random float between 3 and 12 to be used in the gravityScale.
        FindObjectOfType<AudioManager>().Play("Tap"); //Accesses the AudioManager element in the scene to pull the required sound.
        Rigidbody2D gravityOn = gameObject.GetComponent<Rigidbody2D>(); //Gets access to the rigidbody component so the gravityScale can be changed.
        gravityOn.gravityScale = range; //Replaces the gravityScale with the new value.
    }


    // Update is called once per frame. This function is used to check when the object reaches a negative y coordinate, so that it is destroyed.
    // Also prevents the game from running infinitely due to objects descending without being stopped.
    void Update()
    {
        if (transform.position.y <= -500)
        {
            Destroy(this.gameObject); //Destroys the object.
        }
    }

    //This function provides the ability to click on the object, so that it can be counted towards the score.
    private void OnMouseDown()
    {
        GameObject mainCamera = GameObject.Find("Main Camera"); //Finds the active camera object in the scene and all of the public variables within it.
        onStart scoreAmount = mainCamera.GetComponent<onStart>();
        scoreAmount.score--; //Decreases the final score.
        onStart increaseVir = mainCamera.GetComponent<onStart>();
        increaseVir.virCount++; //Increases the count for how many virus objects the player has clicked.
        FindObjectOfType<AudioManager>().Play("Fail"); //Plays the sound titled "Fail" in the AudioManager array.
        Destroy(this.gameObject); //Destroys the object so that the condition to move to the winScreen can be fulfilled.
    }

    //Function used to disable the rigidbody2D component. Not used, but can be accessed out of the object to achieve other goals.
    public void disableRigidbody()
    {
        Rigidbody2D disable = gameObject.GetComponent<Rigidbody2D>(); //Finds the component in the object.
        disable.isKinematic = true; //Disables the component previously found.
    }

    //Function used to disable the circle collider component. Not used, but can be accessed out of the object to achieve other goals.
    public void disableCollision()
    {
        CircleCollider2D disable = gameObject.GetComponent<CircleCollider2D>(); //Finds the component in the object.
        disable.enabled = false; //Disables the component previously found.
    }
}

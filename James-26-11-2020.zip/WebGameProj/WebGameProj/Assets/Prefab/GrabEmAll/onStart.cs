﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


/* This script is attached to the main camera for the scene, and is used to instantiate the objects used within to create the objective for the game.
 * It has various public variables that are used elsewhere in the scene. 
 */
public class onStart : MonoBehaviour
{

    public Transform prefab; // This transform is used to define which prefab is used for the "win" object in the game.
    public Transform prefab2; // This transform defines the "lose" object in the game.
    public GameObject winScreen; // This designates which object is the winScreen, so that it can be placed when the game reaches the end.

    public int score; // This integer is the overall score of the game.
    public int vacCount; // This integer is the total number of "vaccine" objects that have been clicked.
    public int virCount; // This integer is the total number of "virus" objects that have been clicked.


    // Start is called before the first frame update. This function places each of the objects on the screen, and sets the score to 0.
    void Start()
    {

        FindObjectOfType<AudioManager>().Play("Pickup"); // A placeholder sound effect, it is used to signify when the game begins.
        score = 0; // The score has been set to 0.
        
        
        for (int i = 0; i<30;i++) // This for loop places each vaccine object in the scene. It can be manually adjusted by changing the i<30 value, which will either increase or decrease the number of objects.
        {

            int ypos = Random.Range(-30, -499); // The y position of the object is randomized between -30 and -499.
            int xpos = Random.Range(-500, 500); // The x position of the object is randomized between -500 and 500. This spreads the objects over a large area.
            int zpos = 1; // The z position is defined here in the event that it needs to be randomized, or used elsewhere.
            Instantiate(prefab, new Vector3(xpos, ypos, zpos), Quaternion.identity); // The object (prefab) is instantiated using the positions randomly generated previously.
        }

        for(int j = 0; j<20;j++) // This loop instead works for the virus objects. Changing the j<20 value will change how many are created.
        {
            int ypos = Random.Range(-30, -250); // The y position is randomized between -30 and -250. This puts most of the virus objects above the vaccine.
            int xpos = Random.Range(-500, 500); // The x position is randomized between -500 and 500, giving the same spread as the vaccine objects.
            int zpos = 2; // As with the vaccine loop, the z position is defined in case it is needed elsewhere.
            Instantiate(prefab2, new Vector3((xpos + j * 0.2F), ypos, zpos), Quaternion.identity); // The object (prefab2) is instatiated in the same way as the prior loop.
        }
    }
        

    // Update is called once per frame. This function is used to determine if all of the gameObjects have been destroyed. If they have, play the winScreen transform.
    void Update()
    {
        if (GameObject.FindGameObjectWithTag("Virus") == null & GameObject.FindGameObjectWithTag("Vaccine") == null) // Both tags need to return null for the if condition to be fulfilled.
        {
            Instantiate(winScreen, new Vector3(0, 0, 0), Quaternion.identity); // Instantiates a single winScreen object, which enables the winScreen script.
            this.enabled = false; // Disables the entire script, preventing any further instantiation.
        }
    }
}

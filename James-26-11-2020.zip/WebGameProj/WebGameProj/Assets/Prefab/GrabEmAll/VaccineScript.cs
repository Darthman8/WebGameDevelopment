﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;


/* This script adds functionality to the Vaccine in GrabEmAll, which makes
 * the player gain points when they pick it up.
 * The script also contains functionality for swapping gravityScale, and disabling rigidbody2D or collision, which can be called
 * from outside of the object when it is being created.
 */
public class VaccineScript : MonoBehaviour
{
    // Start is called before the first frame update. When a vaccine object is created, this is called first.
    void Start()
    {
        float range = Random.Range(-10f, -5f); //Creates a float that uses a random range to determine how strong the reversed gravity is.
        FindObjectOfType<AudioManager>().Play("Bird3"); //Plays the AudioManager file "Bird3" to signify startup.
        Rigidbody2D gravity = gameObject.GetComponent<Rigidbody2D>(); //Accesses the rigidbody component so that gravity can be altered.
        gravity.gravityScale = range; //The new value is applied to the gravityScale, which will reverse the effect of gravity on the object.
        StartCoroutine(ExecuteAfterTime(5)); //Executes the (ExecuteAfterTime) function which turns gravity back on. The function activates after 5 seconds.
    }

    // Function used to reapply gravity.
    IEnumerator ExecuteAfterTime(float time)
    {
        yield return new WaitForSeconds(time);
        float range = Random.Range(3f, 12f); //The new gravity amount is randomly generated.
        FindObjectOfType<AudioManager>().Play("Tap"); //Plays a sound to signify change (for debug purposes).
        Rigidbody2D gravityOn = gameObject.GetComponent<Rigidbody2D>();
        gravityOn.gravityScale = range; //Applys new value to the gravityScale, making the object fall.
    }



    // Update is called once per frame. This function is used to remove the object if it gets too low. This prevents the game from prepetually running.
    void Update()
    {
        if (transform.position.y <= -500) //When the object falls to or below -500 y, it will destroy it.
        {
            Destroy(this.gameObject); //Destroys the object.
        }
    }

    // This function makes the object add points to the final score and increase the counter for how many vaccine objects
    // have been clicked. It removes the object afterwards.
    private void OnMouseDown()
    {
        GameObject mainCamera = GameObject.Find("Main Camera"); //Finds the active camera on the scene, which contains the script tracking the counters.
        onStart scoreAmount = mainCamera.GetComponent<onStart>();
        scoreAmount.score++; //Increases the total score.
        onStart increaseVac = mainCamera.GetComponent<onStart>();
        increaseVac.vacCount++; //Increases the total count of vaccines clicked.
        FindObjectOfType<AudioManager>().Play("Success"); //Plays a sound to signify the player clicked the correct object.
        
        Destroy(this.gameObject); //Destroys the object to prevent repeated clicking.
    }

    // A function for disabling the rigidbody component, which would remove gravity. Not used, but accessable from outside of the object.
    public void disableRigidbody()
    {
        Rigidbody2D disable = gameObject.GetComponent<Rigidbody2D>();
        disable.isKinematic = true; //Disables the component.
    }

    // A function for disabling the capsule collider component. Not used, but accessable from outside the object.
    public void disableCollision()
    {
        CapsuleCollider2D disable = gameObject.GetComponent<CapsuleCollider2D>();
        disable.enabled = false; //Disables the component.
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

/* This script plays when the winScreen object is instantiated by the onStart script. It displays a black screen, and provides the details of the game,
 * such as what the total score is, how many objects the player clicked, and buttons to replay or go back to the menu. 
 * The text variables initialized at the beginning take text boxes within the winScreen prefab as objects that then have text pushed to them.
 */

public class winScreen : MonoBehaviour
{


    public int score; // A public variable that is converted into the scoreUI variable.
    public Text scoreUI; // A public variable that uses the integer score to generate text based on the total. 
    public Text vacTotal; // A text variable that uses the vacCount variable to generate the total in text.
    public Text virTotal; // A text variable that uses the virCount variable to generate the total in text.
    public Transform virus; // An object using an "empty" version of the virus object, which has no script attached.
    public Transform vaccine; // An object using an "empty" version of the vaccine object, which has no script attached.
    private int virCount; // An integer that acquires the total amount of virus objects clicked.
    private int vacCount; // An integer that acquires the total amount of vaccine objects clicked.

    public Button replayButton, menuButton; // A Button variable that acquires the two buttons in the GUI so that they can have functionality.

    /* When the script is awakened, which is the same point the object is instantiated, it carries out the majority of the code.
     * This script takes the values still stored in the onStart script of the main camera, and puts them into local integer variables
     * so that it can then be used in ToString() to create the text UI. 
     * 
     * The code also uses the totals to instantiate the "empty" objects, to give the player a visual indicator of how many they clicked.
     */
    private void Awake()
    {
        replayButton.onClick.AddListener(replayScene); // Adds a listener to the replay button, which executes the replayScene function when it is pressed.
        menuButton.onClick.AddListener(returnMenu); // Adds a listener to the menu button, which executes the returnMenu function when it is pressed.

        GameObject mainCamera = GameObject.Find("Main Camera"); // Acquires the values within the onStart script so that they can be brought into local integers.
        onStart camera = mainCamera.GetComponent<onStart>();
        virCount = camera.virCount; // Makes the value in virCount the same as the variable in onStart.
        vacCount = camera.vacCount; // Makes the value in vacCount the same as the variable in onStart.
        score = camera.score; // Makes the value in score the same as the variable in onStart.
        scoreUI.text = score.ToString(); // Turns the integer into score into a string that is put in scoreUI, which has a text box associated.
        vacTotal.text = vacCount.ToString();
        virTotal.text = virCount.ToString();

        for (int v = 0; v < vacCount; v++) // For loop that uses the vacCount variable to define how long the loop runs for. It places the total amount of objects on the screen.
        {
            Instantiate(vaccine, new Vector3(v + (30 * v * 2) - 800, -150, 0), Quaternion.identity); // Instantiates the empty object, using an equation to determine the x position of the object.
        }
        for (int i = 0; i < virCount; i++) // For loop that uses the virCount variable to define how long the loop runs for. It places the total amount of objects on the screen.
        {
            Instantiate(virus, new Vector3(i + (30 * i * 2) - 800, 0, 0), Quaternion.identity); // Instantiates the empty object, using an equation to determine the x position of the object.
        }

    }

    // Function that replays the entire scene using the SceneManager.
    private void replayScene()
    {
        SceneManager.LoadScene("GrabEmAll");
    }

    // Placeholder function that will return the user to a menu when pressed.
    private void returnMenu()
    {
        FindObjectOfType<AudioManager>().Play("MessageSend");
        Debug.Log("not yet implemented");
    }
    
}


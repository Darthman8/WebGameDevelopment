﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public int lives = 3;
    public Sprite twoLives;
    public Sprite oneLife;
    private SpriteRenderer spriteRenderer;
   

    // Start is called before the first frame update
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        InvokeRepeating("MoveDown", 1, 1);
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("collision detected");
    }

    private void OnMouseDown()
    {
        transform.Translate(0, 30, 0);
    }


    // Update is called once per frame
    void Update()
    {
        if (lives == 2)
        {
            spriteRenderer.sprite = twoLives;
        }
        else if (lives == 1)
        {
            spriteRenderer.sprite = oneLife;
        }
        
    }


    void MoveDown()
    {
        transform.Translate(0, -20, 0);
    }

}

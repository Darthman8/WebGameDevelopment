﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/* This script is specifically for the detector sprite, which serves to determine when the player has passed a goal.
 * It uses the same principles as the other script with movement, except is purely for detecting collision with the player. 
 */
public class Detector : MonoBehaviour
{
    public float speed;

    // Start is called before the first frame update
    void Start()
    {
        speed = -2f;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("detected");
        GameObject flappyCamera = GameObject.Find("Flappy Camera");
        flappyStart scoreTotal = flappyCamera.GetComponent<flappyStart>();
        scoreTotal.score++;
        FindObjectOfType<AudioManager>().Play("Success");
    
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(speed, 0, 0);

        if (transform.position.x <= -3000)
        {
            Destroy(this.gameObject);
        }

    }
}
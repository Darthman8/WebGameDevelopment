﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class flappyStart : MonoBehaviour
{

    public Transform detector;
    public Transform obstacle1;
    public Transform obstacle2;
    public Transform player;
    public Transform end;
    public Text scoreUI;
    public Text lifeUI;
    

    public float wait;
    public int score;

    // Start is called before the first frame update
    void Start()
    {
        Instantiate(player, new Vector3(-1999, 9, 0), Quaternion.identity);
        score = 0;
        wait = 3;
        
        Time.timeScale = 1;
        InvokeRepeating("Obstacle", wait, wait);
    }

    void Obstacle()
    {
        if(score < 20)
        {
            Instantiate(detector, new Vector3(1458, 237, 0), Quaternion.identity);
            Instantiate(obstacle1, new Vector3(1483, -786, 0), Quaternion.identity);
            Instantiate(obstacle2, new Vector3(1550, 993, 0), Quaternion.identity);
        }
        else
        {
            CancelInvoke();
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        GameObject playerLives = GameObject.FindGameObjectWithTag("Player");
        Player lifeTotal = playerLives.GetComponent<Player>();
        lifeUI.text = lifeTotal.lives.ToString();
        scoreUI.text = score.ToString();
        if(score > 20)
        {
            Instantiate(end, new Vector3(0, 0, 0), Quaternion.identity);
            CancelInvoke();
            this.enabled = false;
        }
        if(lifeTotal.lives <= 0)
        {
            Instantiate(end, new Vector3(0, 0, 0), Quaternion.identity);
            CancelInvoke();
            this.enabled = false;
        }
    }
}

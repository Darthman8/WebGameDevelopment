﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{

    public float speed;
    // Start is called before the first frame update
    void Start()
    {
        speed = -2f;
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("hit");
        GameObject flappyCamera = GameObject.Find("Flappy Camera");
        flappyStart scoreTotal = flappyCamera.GetComponent<flappyStart>();
        scoreTotal.score--;
        GameObject playerLife = GameObject.FindGameObjectWithTag("Player");
        Player lifeTotal = playerLife.GetComponent<Player>();
        lifeTotal.lives--;
        FindObjectOfType<AudioManager>().Play("Fail");
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(speed, 0, 0);
        if (transform.position.x <= -3000)
        {
            Destroy(this.gameObject);
        }

    }
}

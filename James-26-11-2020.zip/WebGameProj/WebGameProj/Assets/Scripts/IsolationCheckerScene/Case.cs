﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;
using System.Xml.Serialization;

public class Case
{
    [XmlElement("ID")]
    public int ID;
    [XmlElement("Name")]
    public string Name;
    [XmlElement("Age")]
    public int Age;
    [XmlElement("Pregnant")]
    public string Pregnant;
}

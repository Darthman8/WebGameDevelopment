﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

[XmlRoot ("CaseCollection")]
public class CaseContainer 
{
    [XmlArray("Cases"), XmlArrayItem("Case")]
    public Case[] Cases;

    public static CaseContainer Load(string path)
    {
        var serializer = new XmlSerializer(typeof(CaseContainer));
        using (var stream = new FileStream(path, FileMode.Open))
        {
            return serializer.Deserialize(stream) as CaseContainer;
        }
    }
}

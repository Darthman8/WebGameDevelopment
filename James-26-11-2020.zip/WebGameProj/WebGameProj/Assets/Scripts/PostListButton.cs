﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;

public class PostListButton : MonoBehaviour
{
    [SerializeField]
    private Text myText;

    public void SetText (string textString)
    {
        myText.text = textString;
    }

    public void OnClick()
    {

    }
}

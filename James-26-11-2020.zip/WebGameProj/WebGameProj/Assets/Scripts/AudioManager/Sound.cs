﻿using UnityEngine;
using UnityEngine.Audio;

[System.Serializable]

/* A script used to generate the array inside of the AudioManager.
 * It standardizes the variables used for the files used in the array.
 */
public class Sound
{
    public string name;

    public AudioClip clip;
    [Range(0f, 1f)] // Establishes a range that the volume can go between. It can be a number between 0.1 and 1.
    public float volume;
    [Range(.1f, 3f)] // Establishes a range that the pitch can go between.It can be a number between 0.1 and 3. 
    public float pitch;

    [HideInInspector]
    public AudioSource source;
}


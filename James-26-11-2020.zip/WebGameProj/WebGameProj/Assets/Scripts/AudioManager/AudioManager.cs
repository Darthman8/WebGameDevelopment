﻿using System;
using UnityEngine;
using UnityEngine;

/* The AudioManger script and prefab of the same name are used to manage audio files for a scene.
 * Throught the AudioManager, it is possible to call defined sound effects within code so that it can occur at the correct time.
 * The AudioManager also makes it simpler to keep track of what sounds are available in specific scenes. 
 * In the inspector, the amount of spaces in the array can be designated.
 */

public class AudioManager : MonoBehaviour
{

    // The array used to store each sound. The array makes use of public variables within the Sound script. 
    public Sound[] sounds; 

    // This function goes through each sound in the array and addes it to an AudioSource component, allowing it to play.
    private void Awake()
    {
        foreach(Sound s in sounds)
        {
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip = s.clip;

            s.source.volume = s.volume;
            s.source.pitch = s.pitch;
        }
    }
    // This function allows external scripts to play the sounds. It accepts the name of the sound as an input, and searches the array for a sound effect of the same name.
    public void Play (string name)
    {
        Sound s = Array.Find(sounds, sound => sound.name == name);
        s.source.Play();
    }

}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;

public class IsolationCaseChecker : MonoBehaviour
{
    int id;
    string caseName;
    int age;
    bool pregnant;


    int i;
    Case currentCase;
    CaseContainer container;
    GameObject documentText;
    GameObject yes;
    GameObject no;
    Text uiText;
    int totalCases;

    // Start is called before the first frame update
    void Start()
    {
        documentText = GameObject.Find("DocumentText");
        yes = GameObject.Find("Yes");
        no = GameObject.Find("No");
        uiText = documentText.GetComponent<Text>();
        container = CaseContainer.Load(Path.Combine(Application.dataPath, "XML/CaseData.xml"));
        totalCases = container.Cases.Length;
        LoadNewCase();
    }

    public void LoadNewCase()
    {
        if (i + 1 <= totalCases)
        {
            currentCase = container.Cases[i];
            i++;
        }

        else
        {
            Debug.Log("Complete");
            yes.GetComponent<Button>().interactable = false;
            no.GetComponent<Button>().interactable = false;
        }

        id = currentCase.ID;
        caseName = currentCase.Name;
        age = currentCase.Age;
        if (currentCase.Pregnant.Equals("True"))
        {
            pregnant = true;
        }
        else if (currentCase.Pregnant.Equals("False"))
        {
            pregnant = false;
        }

        uiText.text = "Name: " + caseName + "\n" + "Age: " + age + "\n" + "\n" + "Pregnancy Status: " + pregnant.ToString();
    }

    public bool CaseShield()
    {
        if (age > 70)
        {
            return true;
        }
        return false;
        //if (pregnant && )
    }

    public void CheckAnswer(bool answer)
    {
        bool caseShield = CaseShield();
        if (caseShield.Equals(answer))
        {
            Debug.Log("true");
        }

        else if (caseShield.Equals(!answer))
        {
            Debug.Log("false");
        }
        LoadNewCase();
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PostListControl : MonoBehaviour
{
    [SerializeField]
    private GameObject postTemplate;

    void Start()
    {
        for (int i = 1; i <= 20; i++)
        {
            GameObject post = Instantiate(postTemplate) as GameObject;
            post.SetActive(true);

            post.GetComponent<PostListButton>().SetText("Post #" + i);

            post.transform.SetParent(postTemplate.transform.parent, false);
        }
    }
}
